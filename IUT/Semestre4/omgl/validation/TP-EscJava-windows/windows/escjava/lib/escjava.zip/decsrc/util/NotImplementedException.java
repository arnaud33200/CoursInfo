package decsrc.util;

public class NotImplementedException extends RuntimeException {
    NotImplementedException(String s) {
	super(s);
    }
}

