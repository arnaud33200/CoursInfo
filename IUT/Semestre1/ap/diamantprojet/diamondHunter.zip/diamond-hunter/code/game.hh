#ifndef GAME_HH
#define GAME_HH

#include "struct.hh"

bool maingame ( SDL_Surface *screen, SDL_Event event, saveconfig &save );

string converter ( int a );

#endif
