#ifndef _UTIL_H_
#define _UTIL_H_

#include <string>
#include <cmath>

using namespace std;

int pgcd(int, int);
string intToString(int); 

#endif
