#include <stdio.h>
#include <stdlib.h>
#include <math.h>



#define LARGEUR 256
#define HAUTEUR 256
#define VAL_MAX 255


#define R 0
#define G 1
#define B 2

#define PI 3.14159265358979323846

#define get_min(a,b) (a<b)?a:b; 
#define get_max(a,b) (a>b)?a:b; 

// Definition du type representant une image en
// niveaux de gris (ndg)
typedef unsigned char ndgIm [LARGEUR][HAUTEUR];
// Image couleur
typedef unsigned char coulIm [LARGEUR][HAUTEUR][3];


// mode = "r" ou "w"
void 
ouvrirFichier (char *nom, FILE **desc, char *mode)
{
  *desc = fopen (nom, mode);
  if (*desc == NULL)
    {
      fprintf (stderr, 
	       "\"%s\": nom de fichier incorrect", 
	       nom);
      if (mode [0] == 'w')
	fprintf (stderr, " ou ouverture en ecriture impossible.");
      exit (EXIT_FAILURE);
    }
}


// Lecture et verification que l'en-tete est correcte et correspond 
// bien a notre mode (P2 = ndg ASCII, P3 = rgb ASCII)
void
lireEnTete (FILE *descFic, char *mode)
{
  char c;
  int v;

  fscanf (descFic, "%c", &c);
  // Lecture du mode
  if (c != mode[0])
    {
      fprintf (stderr, "Mode non defini (%c*).\n", c);
      exit (EXIT_FAILURE);
    }
  fscanf (descFic, "%c", &c);
  if (c != mode[1])
    {
      fprintf (stderr, "%s est necessaire pour une image ASCII en niveaux de gris.\n", mode);
      exit (EXIT_FAILURE);
    }
  // Lecture des dimensions
  fscanf (descFic, "%d", &v);
  if (v != HAUTEUR)
    {
      fprintf (stderr, "La hauteur doit etre de %d.\n", HAUTEUR);
      exit (EXIT_FAILURE);
    }
  fscanf (descFic, "%d", &v);
  if (v != LARGEUR)
    {
      fprintf (stderr, "La largeur doit etre de %d.\n", LARGEUR);
      exit (EXIT_FAILURE);
    }
  // Et lecture de la valeur maximale d'une intensite
  fscanf (descFic, "%d", &v);
  if (v != VAL_MAX)
    {
      fprintf (stderr, "L'intensite maximale doit etre de %d.\n", VAL_MAX);
      exit (EXIT_FAILURE);
    }
}
  

// Lecture d'une image en ndg: mise a jour de la 
// structure de donnees de type ndgIm
void 
lireNdgImage (char *nom, ndgIm im)
{
  FILE *descFic = NULL;
  int c, x, y;

  ouvrirFichier (nom, &descFic, "r");
  lireEnTete (descFic, "P2");

  for (y=0; y < HAUTEUR; y++)  
    for (x=0; x < LARGEUR; x++)
      {
	fscanf (descFic, "%d", &c);
	im [x][y] = c;
      }
  
  fclose (descFic);
}



void lireCoulImage (char *nom, coulIm im)
{
  FILE *descFic = NULL;

  int canalRouge, canalVert, canalBleu, x, y;

  ouvrirFichier (nom, &descFic, "r");
  lireEnTete (descFic, "P3");

  for (y=0; y < HAUTEUR; y++)  
    for (x=0; x < LARGEUR; x++)
      {
	fscanf (descFic, "%d", &canalRouge);
	im [x][y][0] = canalRouge;
	fscanf (descFic, "%d", &canalVert);
	im [x][y][1] = canalVert;
	fscanf (descFic, "%d", &canalBleu);
	im [x][y][2] = canalBleu;
      }
  fclose (descFic);
}




// Ecrit l'en-tete correcte en fonction du mode
// le fichier est deja ouvert
void 
ecrireEnTete (FILE *descFic, char *mode)
{
  fprintf (descFic, "%s\n", mode);
  fprintf (descFic, "%d %d\n", HAUTEUR, LARGEUR);
  fprintf (descFic, "%d\n", VAL_MAX);
}


// Ecrit une image en ndg
void 
ecrireNdgImage (char *nom, ndgIm im)
{
  FILE *descFic = NULL;
  int x, y;
  
  ouvrirFichier (nom, &descFic, "w");
  ecrireEnTete (descFic, "P2");
  
  for (y=0; y < HAUTEUR; y++)
    {
      for (x=0; x < LARGEUR; x++)
	fprintf (descFic, "%d ", im[x][y]);
      fprintf (descFic, "\n");
    }

  fclose (descFic);
}


void 
ecrireCoulImage (char *nom, coulIm im)
{
  FILE *descFic = NULL;
  int x, y;

  ouvrirFichier (nom, &descFic, "w");
  ecrireEnTete (descFic, "P3");
  
  for (y=0; y < HAUTEUR; y++)
    {
      for (x=0; x < LARGEUR; x++)
	{
	  fprintf (descFic, "%d ", im[x][y][0]);
	  fprintf (descFic, "%d ", im[x][y][1]);
	  fprintf (descFic, "%d ", im[x][y][2]);
	}
      fprintf (descFic, "\n");
    }
  fclose (descFic);
}




int 
main ()
{
  ndgIm im, dest;
  
  lireNdgImage ("baboon.pgm", im);
  ecrireNdgImage ("test.pgm", im);

  // Question 5.1 
  ndgIm im1,im2;
  lireNdgImage("diffA.pgm", im1);
  lireNdgImage("diffB.pgm", im2);

  ecrireNdgImage ("diff.pgm",dest);

  // Question 5.2 et 5.3 
  coulIm im3,im4,destC;
  lireCoulImage("fond.ppm", im3);
  lireCoulImage("objet.ppm", im4);

  ecrireCoulImage ("add.ppm",destC);
  ecrireCoulImage ("supp.ppm",destC);

  return EXIT_SUCCESS;
}
